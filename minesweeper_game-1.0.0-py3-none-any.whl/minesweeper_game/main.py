#Imports#
import pygame, random, asyncio, requests, sys
import importlib.resources

#Classes#
class Box():
    def __init__(self, posX, posY, listPos, diff):
        self.flagged = False
        self.posX, self.posY = posX, posY
        self.show = False
        self.listPos = listPos
        match diff:
            case 0:
                diff = 12
            case 1:
                diff = 7
            case 2:
                diff = 3
        tempInt = random.randint(1, diff)
        self.isBomb = False
        if tempInt == 1:
            self.isBomb = True
        self.bombCount = 0
        if (self.listPos + 1) % 20 == 0:
            self.isRight = True
        else:
            self.isRight = False
        if self.listPos == 0 or self.listPos % 20 == 0:
            self.isLeft = True
        else:
            self.isLeft = False
        if self.listPos < 20:
            self.isTop = True
        else:
            self.isTop = False
        if self.listPos > 379:
            self.isBottom = True
        else:
            self.isBottom = False
        if self.isBomb == True:
            self.number = 0
        else:
            self.number = False
    def display(self):
        global win
        colour = (150, 150, 150)
        if self.show:
            colour = (200, 200, 200)
        if win:
            colour = (50, 200, 50)
        pygame.draw.rect(screen, colour, (self.posX, self.posY, 44, 44))
        pygame.draw.rect(screen, (0, 0, 0), (self.posX + 43, self.posY, 1, 44))
        pygame.draw.rect(screen, (0, 0, 0), (self.posX, self.posY + 43, 44, 1))
        if self.show and not self.isBomb and self.bombCount > 0:
            textCol = (182, 34, 136)
            match self.bombCount:
                case 1:
                    textCol = (34, 136, 182)
                case 2:
                    textCol = (34, 182, 136)
                case 3:
                    textCol = (255, 60, 10)
                case 4:
                    textCol = (182, 34, 136)
            number = numFont.render(str(self.bombCount), True, textCol)
            numRect = number.get_rect()
            numRect.x, numRect.y = self.posX + 13, self.posY + 5
            screen.blit(number, numRect)
        elif self.isBomb and self.show:
            screen.blit(bombImage, (self.posX -40, self.posY - 43))
        elif self.flagged and not self.show:
            screen.blit(flagImage, (self.posX, self.posY))
    def countBombs(self):
        bombCount = 0
        for i in range(8):
            match i:
                case 0:
                    run = 0
                    if not self.isTop and not self.isLeft:
                        run = -21
                case 1:
                    run = 0
                    if not self.isTop:
                        run = -20
                case 2:
                    run = 0
                    if not self.isTop and not self.isRight:
                        run = -19
                case 3:
                    run = 0
                    if not self.isLeft:
                        run = -1
                case 4:
                    run = 0
                    if not self.isRight:
                        run = 1
                case 5:
                    run = 0
                    if not self.isBottom and not self.isLeft:
                        run = 19
                case 6:
                    run = 0
                    if not self.isBottom:
                        run = 20
                case 7:
                    run = 0
                    if not self.isRight and not self.isBottom:
                        run = 21
            if squareList[self.listPos + run].isBomb:
                bombCount += 1
        self.bombCount = bombCount
    def revealBlanks(self):
        for i in range(8):
            match i:
                case 0:
                    run = 0
                    if not self.isTop and not self.isLeft:
                        run = -21
                case 1:
                    run = 0
                    if not self.isTop:
                        run = -20
                case 2:
                    run = 0
                    if not self.isTop and not self.isRight:
                        run = -19
                case 3:
                    run = 0
                    if not self.isLeft:
                        run = -1
                case 4:
                    run = 0
                    if not self.isRight:
                        run = 1
                case 5:
                    run = 0
                    if not self.isBottom and not self.isLeft:
                        run = 19
                case 6:
                    run = 0
                    if not self.isBottom:
                        run = 20
                case 7:
                    run = 0
                    if not self.isRight and not self.isBottom:
                        run = 21
            if squareList[self.listPos + run].isBomb == False and not squareList[self.listPos + run].show:
                squareList[self.listPos + run].clicked()
    def clicked(self):
        global lose
        if lose:
            init()
            return
        self.show = True
        if self.isBomb:
            lose = True
            for i in range(len(squareList)):
                if squareList[i].isBomb:
                    squareList[i].show = True
        if self.bombCount == 0 and not self.isBomb:
            self.revealBlanks()

#Functions
def drawBackG():
    pygame.draw.rect(screen, (100, 100, 100), (0, 0, 900, 900))

def makeSquares():
    global squareList, difficulty
    for i in range(20):
        for j in range(20):
            squareList.append(Box(((j*44) + 10), ((i*44) + 10), ((j + 1) + ((i + 1) * 20 - 21)), difficulty))
    for i in range(len(squareList)):
        squareList[i].countBombs()

def drawSquares():
    for i in range(len(squareList)):
        squareList[i].display()

def clickLoop(flag):
    mousePosX, mousePosY = pygame.mouse.get_pos()[0], pygame.mouse.get_pos()[1]
    for i in range(len(squareList)):
        if mousePosX > squareList[i].posX and mousePosX < squareList[i].posX + 44:
            if mousePosY > squareList[i].posY and mousePosY < squareList[i].posY + 44:
                if flag:
                    squareList[i].flagged = not squareList[i].flagged
                    break
                else:
                    squareList[i].show = True
                    squareList[i].clicked()
                    break

def checkWin():
    global win, lose
    winFlag = True
    for i in range(len(squareList)):
        if not squareList[i].show and not squareList[i].isBomb:
            winFlag = False
            break
        else:
            winFlag = True
    if winFlag:
        win = True
        lose = True

def button(colour, text, xPos, yPos):
    global difficulty, gameRun, clicked, gameStart
    if pygame.mouse.get_pos()[0] >= xPos and pygame.mouse.get_pos()[0] < xPos + 200:
        if pygame.mouse.get_pos()[1] >= yPos and pygame.mouse.get_pos()[1] < yPos + 100:
            colour = (colour[0] - 30, colour[1] - 30, colour[2] - 30)
            if clicked:
                clicked = False
                match text:
                    case "EASY":
                        difficulty = 1
                    case "MED":
                        difficulty = 2
                    case "HARD":
                        difficulty = 0
                if text == "PLAY":
                    init()
                    makeSquares()
                    gameStart = True
    pygame.draw.rect(screen, colour, (xPos, yPos, 200, 100))
    wordFont = pygame.font.Font(importlib.resources.files('minesweeper_game').joinpath("assets", "numFont.ttf"), 40)
    number = wordFont.render(text, True, (150, 50, 50))
    numRect = number.get_rect()
    numRect.center = (xPos + 100, yPos + 50)
    screen.blit(number, numRect)

def menuScreen():
    drawBackG()
    wordFont = pygame.font.Font(importlib.resources.files('minesweeper_game').joinpath("assets", "numFont.ttf"), 120)
    number = wordFont.render("BOMB Bastic", True, (150, 50, 50))
    numRect = number.get_rect()
    numRect.x, numRect.y = 90, 20
    screen.blit(number, numRect)
    match difficulty:
        case 0:
            diffText = "EASY"
        case 1:
            diffText = "MED"
        case 2:
            diffText = "HARD"
    button((150, 150, 150), "PLAY", 350, 300)
    button((150, 150, 150), diffText, 350, 420)

def init():
    global gameRun, squareList, lose, win, gameStart
    gameRun, squareList, lose, win, gameStart = True, [], False, False, False

def urlLoad(url):
    try:
        with urllib.request.urlopen(url) as response:
            image_data = response.read()  
        pil_image = Image.open(io.BytesIO(image_data))
        mode = "RGBA" if pil_image.mode == 'RGBA' else "RGB"
        size = pil_image.size
        data = pil_image.tobytes()
        pygame_surface = pygame.image.fromstring(data, size, mode)
        return pygame_surface
    except Exception as e:
        print(f"Error loading image: {e}")
        return None

#Main Loop#
async def main():
    #Initialisation#
    global gameRun, squareList, lose, win, gameStart, difficulty, clicked
    difficulty = 0
    init()
    lGameTick = pygame.time.get_ticks()
    fDelay = 1/30
    clicked = False

    global screen, numFont, bombImage, flagImage
    pygame.init()
    bombImage = pygame.image.load(importlib.resources.files('minesweeper_game').joinpath("assets", "bomb.png"))
    flagImage = pygame.image.load(importlib.resources.files('minesweeper_game').joinpath("assets", "flag.png"))
    screen = pygame.display.set_mode((900, 900))
    numFont = pygame.font.Font(importlib.resources.files('minesweeper_game').joinpath("assets", "numFont.ttf"), 35)
    bombImage = pygame.transform.scale(bombImage, (120, 120)).convert_alpha()
    flagImage = pygame.transform.scale(flagImage, (44, 44)).convert_alpha()
    while gameRun:
        clicked = False
        ticks = pygame.time.get_ticks()
        time = ticks - lGameTick
        lGameTick = ticks
        await asyncio.sleep(fDelay)
        if not gameStart:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    gameRun = False
                if event.type == pygame.MOUSEBUTTONUP:
                    if event.button == 1:
                        clicked = True
            menuScreen()
        else:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    gameRun = False
                if event.type == pygame.MOUSEBUTTONUP:
                    if event.button == 1:
                        clickLoop(False)
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_f:
                        clickLoop(True)
            drawBackG()
            drawSquares()
            checkWin()
        pygame.display.flip()

#start game
if __name__ == "__main__":
    asyncio.run(main())


pygame.quit()
