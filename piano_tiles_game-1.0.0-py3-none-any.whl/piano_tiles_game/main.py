import pygame, random, asyncio

#Classes#
class Tile():
    def __init__(self):
        global prevTile, screen
        self.pos = -240
        col = prevTile
        while col == prevTile:
            col = random.randint(0, 3)
        prevTile = col
        self.col = col
        self.isClicked = False
        self.alpha = 0
        self.trash = False

#Functions#
def renderBackG():
    pygame.draw.rect(screen, (255, 255, 255), (0, 0, 540, 960))
    for i in range(1, 4):
        pygame.draw.rect(screen, (100, 100, 100), (135*i, 0, 1, 960))

def delTiles():
    global tileList, screen
    for i in range(len(tileList) - 1):
        if tileList[i].trash:
            del tileList[i]

def tileLoop():
    global tileList, gameOver, screen
    for i in range(len(tileList)):
        if tileList[i].isClicked and tileList[i].alpha < 120:
            tileList[i].alpha += 5
        pygame.draw.rect(screen, (tileList[i].alpha, tileList[i].alpha, tileList[i].alpha), (tileList[i].col*135, tileList[i].pos, 135, 240))
        tileList[i].pos += gameSpeed
        if tileList[i].pos > 960:
            tileList[i].trash = True
        if tileList[i].pos > 840 and not tileList[i].isClicked:
            gameOver = True

def renderTiles():
    global tileList, screen
    if len(tileList) == 0:
        tileList.append(Tile())
    elif tileList[len(tileList) - 1].pos >= 0:
        tileList.append(Tile())
    tileLoop()
    delTiles()

def keyLoop(keys, deathFlag):
    global tileList, points, screen
    colFlag = False
    for i in range(len(keys)):
        if keys[i]:
            for j in range(len(tileList)):
                if tileList[j].col == i and tileList[j].pos > 580 and tileList[j].pos < 840:
                    if tileList[j].isClicked == False:
                        points += 1
                    tileList[j].isClicked = True
                    deathFlag, colFlag = False, False
                    break
                else:
                    deathFlag, colFlag = True, i*135
    return deathFlag, colFlag


def checkKeys():
    global tileList, gameOver, points, screen
    deathFlag = False
    pressed = pygame.key.get_pressed()
    keys = [pressed[pygame.K_a], pressed[pygame.K_s],
            pressed[pygame.K_k], pressed[pygame.K_l]]
    deathFlag, colFlag = keyLoop(keys, deathFlag)
    if deathFlag:
        gameOver = True
        pygame.draw.rect(screen, (255, 0, 0),   (colFlag, 0, 135, 960))

def renderScore():
    global gameSpeed, screen
    score = scoreFont.render(str(points), True, (34, 136, 182))
    scoreRect = score.get_rect()
    scoreRect.center = (270, 100)
    screen.blit(score, scoreRect)
    if points <= 100:
        gameSpeed = (points / 20) + 3

def renderSelector():
    pygame.draw.rect(screen, (34, 136, 182), (0, 820, 540, 20))

#Main Loop#
async def main():
    #vars#
    global screen, prevTile, scoreFont
    fDelay = 1/120
    lGameTick, gameRun, prevTile = pygame.time.get_ticks(), True, -1
    def reset():
        global gameSpeed, gameOver, tileList, points
        gameSpeed, gameOver, tileList, points = 2, False, [], 0
    global gameSpeed, gameOver, tileList, points
    reset()

    #Screen Resolution#
    sWidth, sHeight = 540, 960

    #Inits#
    pygame.init()
    screen = pygame.display.set_mode((sWidth, sHeight))
    scoreFont = pygame.font.SysFont("arial", 100)
    while gameRun:
        ticks = pygame.time.get_ticks()
        time = ticks - lGameTick
        lGameTick = ticks
        await asyncio.sleep(fDelay)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                gameRun = False
        renderBackG()
        renderTiles()
        checkKeys()
        renderSelector()
        renderScore()
        pygame.display.flip()
        if gameOver:
            reset()

#start game
if __name__ == "__main__":
    asyncio.run(main())

#Close Game#
pygame.quit()
