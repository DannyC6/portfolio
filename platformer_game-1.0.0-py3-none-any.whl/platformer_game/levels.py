#init
import pygame, importlib.resources
pygame.init()
pygame.display.set_mode([1280, 720])

#assets2
stone = pygame.image.load(importlib.resources.files('platformer_game').joinpath("assets", "block.png")).convert()
grass = pygame.image.load(importlib.resources.files('platformer_game').joinpath("assets", "grass.png")).convert()
dirt = pygame.image.load(importlib.resources.files('platformer_game').joinpath("assets", "dirt.png")).convert()
flag = pygame.image.load(importlib.resources.files('platformer_game').joinpath("assets", "flag.png")).convert()
topGrass = pygame.image.load(importlib.resources.files('platformer_game').joinpath("assets", "topGrass.png")).convert()
sideGrassLeft = pygame.image.load(importlib.resources.files('platformer_game').joinpath("assets", "sideGrassLeft.png")).convert()
sideGrassRight = pygame.image.load(importlib.resources.files('platformer_game').joinpath("assets", "sideGrassRight.png")).convert()
grassCornerLeft = pygame.image.load(importlib.resources.files('platformer_game').joinpath("assets", "grassCornerLeft.png")).convert()
grassCornerRight = pygame.image.load(importlib.resources.files('platformer_game').joinpath("assets", "grassCornerRight.png")).convert()

#lvls
level1 = [[0, 5, 11, 12, dirt, 2, 9], [0, 5, 10, 10, grass], [9, 9, 9, 9, grass], [13, 13, 8, 8, grass], [17, 17, 6, 6, grass], [13, 13, 4, 4, grass], [13, 13, 5, 5, dirt], [0, 9, 3, 3, grass], [2, 2, 2, 2, flag]]
level2 = [[0, 5, 11, 12, dirt, 2, 9], [0, 5, 10, 10, grass], [10, 10, 10, 10, grass], [15, 15, 10, 10, grass], [19, 19, 8, 8, grass], [15, 15, 6, 6, grass], [15, 15, 7, 7, dirt], [11, 11, 5, 5, grass], [0, 6, 5, 5, grass], [2, 2, 4, 4, flag]]
level3 = [[0, 2, 11, 12, dirt, 1, 9], [0, 2, 10, 10, grass], [7, 7, 10, 10, grass], [12, 12, 10, 10, grass], [17, 17, 10, 10, grass], [19, 19, 8, 8, grass], [16, 16, 6, 6, grass], [11, 11, 6, 6, grass], [6, 6, 6, 6, grass], [3, 3, 4, 4, grass], [6, 6, 2, 2, grass], [11, 11, 2, 2, grass], [16, 19, 2, 2, grass], [18, 18, 1, 1, flag]]

def addGrass(lvls):
    print("function ran")
    for i in range(len(lvls)):
        for j in range(len(lvls[i])):
            if grass in lvls[i][j]:
                lvls[i].append([lvls[i][j][0], lvls[i][j][1], lvls[i][j][2] - 1, lvls[i][j][2] - 1, topGrass])
                lvls[i].append([lvls[i][j][0] - 1, lvls[i][j][0] - 1, lvls[i][j][2], lvls[i][j][2], sideGrassRight])
                lvls[i].append([lvls[i][j][1] + 1, lvls[i][j][1] + 1, lvls[i][j][2], lvls[i][j][2], sideGrassLeft])
                lvls[i].append([lvls[i][j][0] - 1, lvls[i][j][0] - 1, lvls[i][j][2] - 1, lvls[i][j][2] - 1, grassCornerRight])
                lvls[i].append([lvls[i][j][1] + 1, lvls[i][j][1] + 1, lvls[i][j][2] - 1, lvls[i][j][2] - 1, grassCornerLeft])
                print("grass added")
    return lvls

#create list of all levels
gameLevels = [level1, level2, level3]
